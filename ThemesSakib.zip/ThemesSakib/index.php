<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bangladesh</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href=".">
    <?php wp_head(); ?>
</head>
<body>
    <!-- header part start -->
    <header class="cont">
        <div class="row topbar">
            <div class="col-lg-6 header-left">
                <p>বাংলাদেশ জাতীয় তথ্য বাতায়ন</p>
            </div>
            <div class="col-lg-6 header-right text-end">
                <p>২৩ কার্তিক, ১৪২৯</p>
                <a href="#">English</a>
            </div>
        </div>
    </header>
    <!-- header part end -->
    <!-- logo part start -->
    <section class="cont">
        <div class="row logo">
            <div class="col-lg-5 logo-left">
                <a href="#">
                  <?php the_custom_logo(); ?>
                  <img src="./assets/Images/header/logo_bn.png" alt="img">
                </a>
            </div>
            <div class="col-lg-5 logo-search">
                <form action="">
                    <input type="text" placeholder="খুঁজুন" >
                    <button>অনুসন্ধান </button>
                </form>
            </div>
            <div class="col-lg-2 logo-right d-flex justify-content-end">
                <div class="logo1">
                    <a href="#"><img src="./assets/Images/header/a2i-logo-footer.png" alt="img"></a>
                </div>
                <div class="logo2">
                    <h5><b>সাথে থাকুন:</b></h5>
                    <a href="#"><img src="./assets/Images/header/facebook-icon.png" alt=""></a>
                    <a href="#"><img src="./assets/Images/header/twitter-blue-icon.png" alt=""></a>
                    <a href="#"><img src="./assets/Images/header/youtube-icon.png" alt=""></a>
                    <a href="#"><img src="./assets/Images/header/gplus-icon.png" alt=""></a>
                </div>
            </div>
        </div>
    </section>
    <!-- logo part end -->
    <!-- menu part start -->
    <section class="cont">
        <div class="row main-menu">
            <nav class="navbar navbar-expand-lg bg-light">
                <div class="container-fluid">
                  
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">হোম</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">বাংলাদেশ সম্পর্কিত</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">ই-সেবাসমূহ</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">সেবাখাত</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">ব্যবসা-বাণিজ্য</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#"> বৈদেশিক বিনিয়োগ</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">আইন-বিধি</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">তথ্য বাতায়ন</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">সেবাকুঞ্জ</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">ফরমস</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </nav>
        </div>
    </section>
    <!-- menu part end -->
    <!-- hero part start -->
    <section class="cont">
      <div class="row hero">
        <div class="hero-main col-lg-8">
          <div class="banner">
            <a href="#"><img src="./assets/Images/padmabanner.jpg" class="d-block w-100" alt="img"></a>
          </div>
          <!-- slider part start -->
          <div class="slider">
            <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="./assets/Images/slider/0.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="./assets/Images/slider/333_gov.png" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="./assets/Images/slider/corona_banner.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="./assets/Images/slider/myGov Static2(1) (1).jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="./assets/Images/slider/our_pride.png" class="d-block w-100" alt="...">
                </div>
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
          <!-- slider part end -->
          <div class="tap">
            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
              <li class="nav-item" role="presentation">
                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">জনপ্রিয় সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">নতুন সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">মোবাইল সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false">দপ্তর ভিত্তিক সেবা</button>
              </li>
            </ul>
            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                <div class="row">
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./assets/Images/tab/agriculture.png" alt=""></a>
                    <p>কৃষি</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./assets/Images/tab/call_center.png" alt=""></a>
                    <p>কল সেন্টার</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./assets/Images/tab/helpdesk.png" alt=""></a>
                    <p>হেল্পডেস্ক</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./assets/Images/tab/mobile_service.png" alt=""></a>
                    <p>মোবাইল সেবা</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./assets/Images/tab/agriculture.png" alt=""></a>
                    <p>মৎস্য ও প্রাণী</p>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                <div class="row">
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./assets/Images/tab/agriculture.png" alt=""></a>
                    <p>কৃষি</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./assets/Images/tab/call_center.png" alt=""></a>
                    <p>কল সেন্টার</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./assets/Images/tab/helpdesk.png" alt=""></a>
                    <p>হেল্পডেস্ক</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./assets/Images/tab/mobile_service.png" alt=""></a>
                    <p>মোবাইল সেবা</p>
                  </div>
                  <div class="col-lg-2 text-center">
                    <a href="#"><img src="./assets/Images/tab/agriculture.png" alt=""></a>
                    <p>মৎস্য ও প্রাণী</p>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">C</div>
              <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">D</div>
            </div>
          </div>
          <div class="list">
            <h5>উদ্যোগ</h5>
            <ul>
              <li><a href="#">বাংলাদেশ সরকারের সপ্তম পঞ্চবার্ষিক পরিকল্পনা (২০১৬-২০২০) 2016-06-13</a></li>
              <li><a href="#">বাংলাদেশে ঘূর্ণিঝড়ের জরুরি প্রস্তুতি পরিকল্পনা। (2015-04-11)</a></li>
              <li><a href="#">বাংলাদেশ সরকারের ষষ্ঠ পঞ্চবার্ষিক পরিকল্পনা। (2015-04-07)</a></li>
              <li><a href="#">বাংলাদেশ সরকারের প্রেক্ষিত পরিকল্পনা (২০১০-২০২১)।</a></li>
              <li><a href="#">দূর্যোগ ব্যবস্থাপনা জন্য জাতীয় পরিকল্পনা ২০১০-২০১৫।</a></li>
            </ul>
          </div>
          <div class="others">Other</div>
        </div>
        <div class="hero-side col-lg-4">
          <div class="side-img">
            <a href="#"><img src="./assets/Images/sidebar/Bangladesh-Directory.jpg" class="d-block w-100" alt=""></a>
          </div>
          <div class="side-img">
            <a href="#"><img src="./assets/Images/sidebar/bangladesh-portal--batton-bangla.png" class="d-block w-100" alt=""></a>
          </div>
          <div class="side-img">
            <a href="#"><img src="./assets/Images/sidebar/dengu.jpg" class="d-block w-100" alt=""></a>
          </div>
          <div class="side-img">
            <a href="#"><img src="./assets/Images/sidebar/Jonotar-Sorkar-banner-Bangl (1).jpg" class="d-block w-100" alt=""></a>
          </div>
          <div class="side-img">
            <a href="#"><img src="./assets/Images/sidebar/mask-bd-portal (1).jpg" class="d-block w-100" alt=""></a>
          </div>
          <div class="side-img">
            <a href="#"><img src="./assets/Images/sidebar/mygov_bn.jpg" class="d-block w-100" alt=""></a>
          </div>
          <h5>সকল বাতায়ন</h5>
          <form action="">
            <select name="" id="">
              <option value="">ওয়েবসাইট বাছাই করুন</option>
              <option value="">মন্ত্রণালয়</option>
              <option value="">অধিদপ্তর </option>
              <option value="">ঢাকা বিভাগ</option>
              <option value="">চট্টগ্রাম বিভাগ</option>
              <option value="">রাজশাহী বিভাগ</option>
              <option value="">রংপুর বিভাগ</option>
            </select>
            <button>চলুন</button>
          </form>
          <div class="side-video">
            <h5>ডিজিটাল বাংলাদেশ এর এগিয়ে যাওয়ার ১২ বছর</h5>
            <iframe width="315" height="220" src="https://www.youtube.com/embed/B0FgrYBE4uY" title="মাননীয় প্রধানমন্ত্রী জননেত্রী শেখ হাসিনার নেতৃত্বে ডিজিটাল বাংলাদেশ এর এগিয়ে যাওয়ার ১২ বছর।" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
        </div>
      </div>
    </section>
    <!-- hero part end -->
    <!-- footer part start -->
    <footer class="cont-p mt-5">
      <div class="row footer-main">
        <img src="./assets/Images/footer/download.png" alt="">
      </div>
      <div class="row footer-bottom">
        <div class="col-lg-7 fb-left">l</div>
        <div class="col-lg-7 fb-right">r</div>
      </div>
    </footer>
    <!-- footer part end -->


    <?php wp_footer(); ?>
    <script src="./assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>